﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Jeu
    Inherits System.Windows.Forms.Form

    'Form remplace la méthode Dispose pour nettoyer la liste des composants.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requise par le Concepteur Windows Form
    Private components As System.ComponentModel.IContainer

    'REMARQUE : la procédure suivante est requise par le Concepteur Windows Form
    'Elle peut être modifiée à l'aide du Concepteur Windows Form.  
    'Ne la modifiez pas à l'aide de l'éditeur de code.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.SuspendLayout()
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(1052, 75)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(85, 23)
        Me.Button1.TabIndex = 0
        Me.Button1.Text = "Abandon"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(80, 140)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(95, 123)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Label1"
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(200, 140)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(95, 123)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Label2"
        '
        'Label10
        '
        Me.Label10.Location = New System.Drawing.Point(80, 280)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(95, 123)
        Me.Label10.TabIndex = 6
        Me.Label10.Text = "Label10"
        '
        'Label3
        '
        Me.Label3.Location = New System.Drawing.Point(320, 140)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(95, 123)
        Me.Label3.TabIndex = 7
        Me.Label3.Text = "Label3"
        '
        'Label4
        '
        Me.Label4.Location = New System.Drawing.Point(440, 140)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(95, 123)
        Me.Label4.TabIndex = 8
        Me.Label4.Text = "Label4"
        '
        'Label5
        '
        Me.Label5.Location = New System.Drawing.Point(560, 140)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(95, 123)
        Me.Label5.TabIndex = 9
        Me.Label5.Text = "Label5"
        '
        'Label6
        '
        Me.Label6.Location = New System.Drawing.Point(200, 280)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(95, 123)
        Me.Label6.TabIndex = 10
        Me.Label6.Text = "Label6"
        '
        'Label7
        '
        Me.Label7.Location = New System.Drawing.Point(320, 280)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(95, 123)
        Me.Label7.TabIndex = 11
        Me.Label7.Text = "Label7"
        '
        'Label8
        '
        Me.Label8.Location = New System.Drawing.Point(440, 280)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(95, 123)
        Me.Label8.TabIndex = 12
        Me.Label8.Text = "Label8"
        '
        'Label9
        '
        Me.Label9.Location = New System.Drawing.Point(560, 280)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(95, 123)
        Me.Label9.TabIndex = 13
        Me.Label9.Text = "Label9"
        '
        'Label11
        '
        Me.Label11.Location = New System.Drawing.Point(560, 559)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(95, 123)
        Me.Label11.TabIndex = 23
        Me.Label11.Text = "Label11"
        '
        'Label12
        '
        Me.Label12.Location = New System.Drawing.Point(440, 559)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(95, 123)
        Me.Label12.TabIndex = 22
        Me.Label12.Text = "Label12"
        '
        'Label13
        '
        Me.Label13.Location = New System.Drawing.Point(320, 559)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(95, 123)
        Me.Label13.TabIndex = 21
        Me.Label13.Text = "Label13"
        '
        'Label14
        '
        Me.Label14.Location = New System.Drawing.Point(200, 559)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(95, 123)
        Me.Label14.TabIndex = 20
        Me.Label14.Text = "Label14"
        '
        'Label15
        '
        Me.Label15.Location = New System.Drawing.Point(560, 419)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(95, 123)
        Me.Label15.TabIndex = 19
        Me.Label15.Text = "Label15"
        '
        'Label16
        '
        Me.Label16.Location = New System.Drawing.Point(440, 419)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(95, 123)
        Me.Label16.TabIndex = 18
        Me.Label16.Text = "Label16"
        '
        'Label17
        '
        Me.Label17.Location = New System.Drawing.Point(320, 419)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(95, 123)
        Me.Label17.TabIndex = 17
        Me.Label17.Text = "Label17"
        '
        'Label18
        '
        Me.Label18.Location = New System.Drawing.Point(80, 559)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(95, 123)
        Me.Label18.TabIndex = 16
        Me.Label18.Text = "Label18"
        '
        'Label19
        '
        Me.Label19.Location = New System.Drawing.Point(200, 419)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(95, 123)
        Me.Label19.TabIndex = 15
        Me.Label19.Text = "Label19"
        '
        'Label20
        '
        Me.Label20.Location = New System.Drawing.Point(80, 419)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(95, 123)
        Me.Label20.TabIndex = 14
        Me.Label20.Text = "Label20"
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(80, 54)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(54, 16)
        Me.Label21.TabIndex = 24
        Me.Label21.Text = "Joueur :"
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(200, 54)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(55, 16)
        Me.Label22.TabIndex = 25
        Me.Label22.Text = "Label22"
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(337, 54)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(106, 16)
        Me.Label23.TabIndex = 26
        Me.Label23.Text = "- Temps restant :"
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Location = New System.Drawing.Point(480, 54)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(55, 16)
        Me.Label24.TabIndex = 27
        Me.Label24.Text = "Label24"
        '
        'Timer1
        '
        '
        'Jeu
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1253, 723)
        Me.Controls.Add(Me.Label24)
        Me.Controls.Add(Me.Label23)
        Me.Controls.Add(Me.Label22)
        Me.Controls.Add(Me.Label21)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.Label15)
        Me.Controls.Add(Me.Label16)
        Me.Controls.Add(Me.Label17)
        Me.Controls.Add(Me.Label18)
        Me.Controls.Add(Me.Label19)
        Me.Controls.Add(Me.Label20)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Button1)
        Me.Name = "Jeu"
        Me.Text = "jeu"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Button1 As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents Label16 As Label
    Friend WithEvents Label17 As Label
    Friend WithEvents Label18 As Label
    Friend WithEvents Label19 As Label
    Friend WithEvents Label20 As Label
    Friend WithEvents Label21 As Label
    Friend WithEvents Label22 As Label
    Friend WithEvents Label23 As Label
    Friend WithEvents Label24 As Label
    Friend WithEvents Timer1 As Timer
End Class
